﻿namespace Management
{
    partial class F060101
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cbxCollector = new System.Windows.Forms.ComboBox();
            this.ds_data = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataTable5 = new System.Data.DataTable();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataColumn44 = new System.Data.DataColumn();
            this.dataColumn45 = new System.Data.DataColumn();
            this.dataColumn46 = new System.Data.DataColumn();
            this.dataColumn47 = new System.Data.DataColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(51, 339);
            this.txtCount.Margin = new System.Windows.Forms.Padding(2);
            this.txtCount.Name = "txtCount";
            this.txtCount.Size = new System.Drawing.Size(51, 20);
            this.txtCount.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 342);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 42;
            this.label4.Text = "Jumlah";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(435, 3);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 41);
            this.button1.TabIndex = 41;
            this.button1.Text = "Proses";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(249, 28);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(168, 20);
            this.textBox2.TabIndex = 40;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(64, 24);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(168, 20);
            this.textBox1.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 37;
            this.label3.Text = "PK";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(249, 5);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(168, 20);
            this.textBox8.TabIndex = 35;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(64, 46);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(151, 20);
            this.dateTimePicker2.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 50);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "Tgl Bayar";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 3);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "Collector";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 98);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(774, 236);
            this.dataGridView1.TabIndex = 44;
            // 
            // cbxCollector
            // 
            this.cbxCollector.FormattingEnabled = true;
            this.cbxCollector.Location = new System.Drawing.Point(64, 1);
            this.cbxCollector.Name = "cbxCollector";
            this.cbxCollector.Size = new System.Drawing.Size(168, 21);
            this.cbxCollector.TabIndex = 45;
            // 
            // ds_data
            // 
            this.ds_data.DataSetName = "NewDataSet";
            this.ds_data.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2,
            this.dataTable3,
            this.dataTable4,
            this.dataTable5});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27});
            this.dataTable1.TableName = "NASABAH";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NO_KTP";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "NO_KK";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AGAMA";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "JK";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TELP";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PEKERJAAN";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "NAMA_BANK";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "NO_REKENING";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "NAMA_SALES";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "STATUS_APPL";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36});
            this.dataTable2.TableName = "JAMINAN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "KET1";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "KET2";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "NAMA_COLLECTOR";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn37,
            this.dataColumn38});
            this.dataTable3.TableName = "SALES";
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "SALES_ID";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "NM_SALES";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn39});
            this.dataTable4.TableName = "COLLECTOR";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "NM_COLLECTOR";
            // 
            // dataTable5
            // 
            this.dataTable5.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn40,
            this.dataColumn41,
            this.dataColumn42,
            this.dataColumn43,
            this.dataColumn44,
            this.dataColumn45,
            this.dataColumn46,
            this.dataColumn47});
            this.dataTable5.TableName = "PINJAMAN";
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "NM_NASABAH";
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "NM_SALES";
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "NM_COLLECTOR";
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "SALES_ID";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "COLLECTOR_ID";
            // 
            // dataColumn45
            // 
            this.dataColumn45.ColumnName = "JLH_PINJAMAN";
            // 
            // dataColumn46
            // 
            this.dataColumn46.ColumnName = "TIPE_PINJAMAN";
            // 
            // dataColumn47
            // 
            this.dataColumn47.ColumnName = "JLH_TENOR";
            // 
            // F060101
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbxCollector);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Name = "F060101";
            this.Size = new System.Drawing.Size(822, 412);
            this.Load += new System.EventHandler(this.F060101_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cbxCollector;
        public System.Data.DataSet ds_data;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataTable dataTable5;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataColumn dataColumn44;
        private System.Data.DataColumn dataColumn45;
        private System.Data.DataColumn dataColumn46;
        private System.Data.DataColumn dataColumn47;
    }
}
