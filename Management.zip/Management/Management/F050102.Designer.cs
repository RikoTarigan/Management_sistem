﻿namespace Management
{
    partial class F050102
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtKeterangan = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dtmTanggalMasuk = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTypeBarang = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txtNamaBarang = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtJaminan = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNamaAnggota = new System.Windows.Forms.TextBox();
            this.txtNoAnggota = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Detail = new System.Windows.Forms.GroupBox();
            this.cbxJenisJaminan = new System.Windows.Forms.ComboBox();
            this.cbxCollector = new System.Windows.Forms.ComboBox();
            this.ds_data = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn44 = new System.Data.DataColumn();
            this.Detail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(45, 390);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 31);
            this.btnSave.TabIndex = 144;
            this.btnSave.Text = "Simpan";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtKeterangan
            // 
            this.txtKeterangan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKeterangan.Location = new System.Drawing.Point(399, 120);
            this.txtKeterangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtKeterangan.Multiline = true;
            this.txtKeterangan.Name = "txtKeterangan";
            this.txtKeterangan.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtKeterangan.Size = new System.Drawing.Size(306, 106);
            this.txtKeterangan.TabIndex = 13;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(329, 120);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 13);
            this.label21.TabIndex = 142;
            this.label21.Text = "Keterangan";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(399, 81);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 11;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(320, 81);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 13);
            this.label18.TabIndex = 140;
            this.label18.Text = "Status Stock";
            // 
            // dtmTanggalMasuk
            // 
            this.dtmTanggalMasuk.Enabled = false;
            this.dtmTanggalMasuk.Location = new System.Drawing.Point(399, 57);
            this.dtmTanggalMasuk.Margin = new System.Windows.Forms.Padding(2);
            this.dtmTanggalMasuk.Name = "dtmTanggalMasuk";
            this.dtmTanggalMasuk.Size = new System.Drawing.Size(151, 20);
            this.dtmTanggalMasuk.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(331, 63);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 13);
            this.label17.TabIndex = 138;
            this.label17.Text = "Tgl Masuk";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(317, 97);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 136;
            this.label16.Text = "Nama Collector";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 141);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 135;
            this.label12.Text = "Harga";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(80, 138);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(224, 20);
            this.textBox10.TabIndex = 134;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 77);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 133;
            this.label13.Text = "No Mesin";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(81, 74);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(224, 20);
            this.textBox11.TabIndex = 132;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 121);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 131;
            this.label14.Text = "No BPKB";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 99);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 130;
            this.label15.Text = "No Rangka";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(80, 117);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(224, 20);
            this.textBox12.TabIndex = 129;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(81, 96);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(224, 20);
            this.textBox13.TabIndex = 128;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 56);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 127;
            this.label7.Text = "Atas Nama";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(81, 52);
            this.textBox18.Margin = new System.Windows.Forms.Padding(2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(224, 20);
            this.textBox18.TabIndex = 126;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 34);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 123;
            this.label9.Text = "Tgl STNK";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 13);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 122;
            this.label11.Text = "Nomor Polisi";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(81, 31);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(224, 20);
            this.textBox8.TabIndex = 121;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(81, 9);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(224, 20);
            this.textBox9.TabIndex = 120;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 188);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 118;
            this.label3.Text = "Type Barang";
            // 
            // txtTypeBarang
            // 
            this.txtTypeBarang.Location = new System.Drawing.Point(89, 184);
            this.txtTypeBarang.Margin = new System.Windows.Forms.Padding(2);
            this.txtTypeBarang.Name = "txtTypeBarang";
            this.txtTypeBarang.Size = new System.Drawing.Size(224, 20);
            this.txtTypeBarang.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 122);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 116;
            this.label4.Text = "Diterima Dari";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(89, 119);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(224, 20);
            this.textBox4.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 167);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 114;
            this.label5.Text = "Merk Barang";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 141);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 113;
            this.label6.Text = "Nama Barang";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(89, 163);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(224, 20);
            this.textBox5.TabIndex = 7;
            // 
            // txtNamaBarang
            // 
            this.txtNamaBarang.Location = new System.Drawing.Point(89, 141);
            this.txtNamaBarang.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaBarang.Name = "txtNamaBarang";
            this.txtNamaBarang.Size = new System.Drawing.Size(224, 20);
            this.txtNamaBarang.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 102);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 13);
            this.label20.TabIndex = 110;
            this.label20.Text = "Jenis Jaminan";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 58);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 109;
            this.label19.Text = "Jaminan Id";
            // 
            // txtJaminan
            // 
            this.txtJaminan.Location = new System.Drawing.Point(89, 54);
            this.txtJaminan.Margin = new System.Windows.Forms.Padding(2);
            this.txtJaminan.Name = "txtJaminan";
            this.txtJaminan.Size = new System.Drawing.Size(224, 20);
            this.txtJaminan.TabIndex = 2;
            this.txtJaminan.TextChanged += new System.EventHandler(this.txtJaminan_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 106;
            this.label2.Text = "Nama Anggota";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 105;
            this.label1.Text = "No Anggota";
            // 
            // txtNamaAnggota
            // 
            this.txtNamaAnggota.Location = new System.Drawing.Point(89, 76);
            this.txtNamaAnggota.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaAnggota.Name = "txtNamaAnggota";
            this.txtNamaAnggota.Size = new System.Drawing.Size(224, 20);
            this.txtNamaAnggota.TabIndex = 3;
            // 
            // txtNoAnggota
            // 
            this.txtNoAnggota.Enabled = false;
            this.txtNoAnggota.Location = new System.Drawing.Point(88, 2);
            this.txtNoAnggota.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoAnggota.Multiline = true;
            this.txtNoAnggota.Name = "txtNoAnggota";
            this.txtNoAnggota.Size = new System.Drawing.Size(225, 29);
            this.txtNoAnggota.TabIndex = 103;
            this.txtNoAnggota.TextChanged += new System.EventHandler(this.txtNoAnggota_TextChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(317, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(51, 29);
            this.button3.TabIndex = 1;
            this.button3.Text = "Cari";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Detail
            // 
            this.Detail.Controls.Add(this.label11);
            this.Detail.Controls.Add(this.textBox9);
            this.Detail.Controls.Add(this.textBox8);
            this.Detail.Controls.Add(this.label9);
            this.Detail.Controls.Add(this.textBox18);
            this.Detail.Controls.Add(this.label7);
            this.Detail.Controls.Add(this.textBox13);
            this.Detail.Controls.Add(this.textBox12);
            this.Detail.Controls.Add(this.label15);
            this.Detail.Controls.Add(this.label14);
            this.Detail.Controls.Add(this.textBox11);
            this.Detail.Controls.Add(this.label13);
            this.Detail.Controls.Add(this.label12);
            this.Detail.Controls.Add(this.textBox10);
            this.Detail.Location = new System.Drawing.Point(8, 207);
            this.Detail.Name = "Detail";
            this.Detail.Size = new System.Drawing.Size(316, 178);
            this.Detail.TabIndex = 9;
            this.Detail.TabStop = false;
            this.Detail.VisibleChanged += new System.EventHandler(this.Detail_VisibleChanged);
            // 
            // cbxJenisJaminan
            // 
            this.cbxJenisJaminan.FormattingEnabled = true;
            this.cbxJenisJaminan.Items.AddRange(new object[] {
            "Kendaraan",
            "Surat",
            "Barang",
            "Emas",
            "dll"});
            this.cbxJenisJaminan.Location = new System.Drawing.Point(89, 97);
            this.cbxJenisJaminan.Name = "cbxJenisJaminan";
            this.cbxJenisJaminan.Size = new System.Drawing.Size(223, 21);
            this.cbxJenisJaminan.TabIndex = 4;
            this.cbxJenisJaminan.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cbxCollector
            // 
            this.cbxCollector.FormattingEnabled = true;
            this.cbxCollector.Location = new System.Drawing.Point(399, 97);
            this.cbxCollector.Name = "cbxCollector";
            this.cbxCollector.Size = new System.Drawing.Size(306, 21);
            this.cbxCollector.TabIndex = 12;
            // 
            // ds_data
            // 
            this.ds_data.DataSetName = "NewDataSet";
            this.ds_data.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2,
            this.dataTable3,
            this.dataTable4});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27});
            this.dataTable1.TableName = "NASABAH";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NO_KTP";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "NO_KK";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AGAMA";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "JK";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TELP";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PEKERJAAN";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "NAMA_BANK";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "NO_REKENING";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "NAMA_SALES";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "STATUS_APPL";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36});
            this.dataTable2.TableName = "JAMINAN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "KET1";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "KET2";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "NAMA_COLLECTOR";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn37,
            this.dataColumn38,
            this.dataColumn39,
            this.dataColumn40,
            this.dataColumn42,
            this.dataColumn41,
            this.dataColumn43});
            this.dataTable3.TableName = "SALES";
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "Stts";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "Chk";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "SALES_ID";
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "NM_SALES";
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "TELP_SALES";
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "ALAMAT_SALES";
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "IS_ACTIVE";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn44});
            this.dataTable4.TableName = "collector";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "NM_COLLECTOR";
            // 
            // F050102
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbxCollector);
            this.Controls.Add(this.cbxJenisJaminan);
            this.Controls.Add(this.Detail);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtKeterangan);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.dtmTanggalMasuk);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTypeBarang);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.txtNamaBarang);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtJaminan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNamaAnggota);
            this.Controls.Add(this.txtNoAnggota);
            this.Name = "F050102";
            this.Size = new System.Drawing.Size(771, 590);
            this.Load += new System.EventHandler(this.F050102_Load);
            this.Detail.ResumeLayout(false);
            this.Detail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtKeterangan;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dtmTanggalMasuk;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTypeBarang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox txtNamaBarang;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtJaminan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNamaAnggota;
        private System.Windows.Forms.TextBox txtNoAnggota;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox Detail;
        private System.Windows.Forms.ComboBox cbxJenisJaminan;
        private System.Windows.Forms.ComboBox cbxCollector;
        public System.Data.DataSet ds_data;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn44;
    }
}
