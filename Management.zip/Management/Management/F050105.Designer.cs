﻿namespace Management
{
    partial class F050105
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.namasales = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtKet = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtLokasiTagih = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.cbxGrup = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.cbxCollector = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.txtByAdmin = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtjlhbunga = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.rdbBulanan = new System.Windows.Forms.RadioButton();
            this.rdbMingguan = new System.Windows.Forms.RadioButton();
            this.rdbHarian = new System.Windows.Forms.RadioButton();
            this.label43 = new System.Windows.Forms.Label();
            this.txtNoAnggota = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ds_data = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNomorKK = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNomorKTP = new System.Windows.Forms.TextBox();
            this.txtNamaCustomer = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtPekerjaan = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAlamatDomisili = new System.Windows.Forms.TextBox();
            this.txtAlamatKTp = new System.Windows.Forms.TextBox();
            this.txtTelp = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtTanggalLahirIbu = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtNamaIbuKandung = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtJenisUsaha = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAlamatUsaha = new System.Windows.Forms.TextBox();
            this.txtNamaUsaha = new System.Windows.Forms.TextBox();
            this.DetailPasangan = new System.Windows.Forms.GroupBox();
            this.txtnamapasangan = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtnoktppasangan = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtalamatpasangan = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtnotelppasangan = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn39 = new System.Data.DataColumn();
            this.nudJlhPinjaman = new System.Windows.Forms.NumericUpDown();
            this.nudTenor = new System.Windows.Forms.NumericUpDown();
            this.txtjlhbnga = new System.Windows.Forms.TextBox();
            this.txtSuveryor = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            this.DetailPasangan.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJlhPinjaman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenor)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 500);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 31);
            this.button1.TabIndex = 15;
            this.button1.Text = "Simpan";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // namasales
            // 
            this.namasales.FormattingEnabled = true;
            this.namasales.Location = new System.Drawing.Point(569, 391);
            this.namasales.Margin = new System.Windows.Forms.Padding(2);
            this.namasales.Name = "namasales";
            this.namasales.Size = new System.Drawing.Size(122, 21);
            this.namasales.TabIndex = 14;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(501, 395);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(33, 13);
            this.label54.TabIndex = 249;
            this.label54.Text = "Sales";
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // txtKet
            // 
            this.txtKet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKet.Location = new System.Drawing.Point(570, 417);
            this.txtKet.Margin = new System.Windows.Forms.Padding(2);
            this.txtKet.Multiline = true;
            this.txtKet.Name = "txtKet";
            this.txtKet.Size = new System.Drawing.Size(318, 83);
            this.txtKet.TabIndex = 13;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(486, 421);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(80, 13);
            this.label55.TabIndex = 247;
            this.label55.Text = "Ket. Pot. Admin";
            // 
            // txtLokasiTagih
            // 
            this.txtLokasiTagih.Location = new System.Drawing.Point(359, 480);
            this.txtLokasiTagih.Margin = new System.Windows.Forms.Padding(2);
            this.txtLokasiTagih.Name = "txtLokasiTagih";
            this.txtLokasiTagih.Size = new System.Drawing.Size(123, 20);
            this.txtLokasiTagih.TabIndex = 12;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(287, 480);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(68, 13);
            this.label53.TabIndex = 245;
            this.label53.Text = "Lokasi Tagih";
            // 
            // cbxGrup
            // 
            this.cbxGrup.FormattingEnabled = true;
            this.cbxGrup.Location = new System.Drawing.Point(359, 458);
            this.cbxGrup.Margin = new System.Windows.Forms.Padding(2);
            this.cbxGrup.Name = "cbxGrup";
            this.cbxGrup.Size = new System.Drawing.Size(123, 21);
            this.cbxGrup.TabIndex = 11;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(315, 459);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(36, 13);
            this.label52.TabIndex = 243;
            this.label52.Text = "Group";
            // 
            // cbxCollector
            // 
            this.cbxCollector.FormattingEnabled = true;
            this.cbxCollector.Location = new System.Drawing.Point(359, 435);
            this.cbxCollector.Margin = new System.Windows.Forms.Padding(2);
            this.cbxCollector.Name = "cbxCollector";
            this.cbxCollector.Size = new System.Drawing.Size(123, 21);
            this.cbxCollector.TabIndex = 10;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(304, 439);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(48, 13);
            this.label51.TabIndex = 241;
            this.label51.Text = "Collector";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(304, 417);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(49, 13);
            this.label50.TabIndex = 239;
            this.label50.Text = "Surveyor";
            // 
            // txtByAdmin
            // 
            this.txtByAdmin.Location = new System.Drawing.Point(359, 392);
            this.txtByAdmin.Margin = new System.Windows.Forms.Padding(2);
            this.txtByAdmin.Name = "txtByAdmin";
            this.txtByAdmin.Size = new System.Drawing.Size(123, 20);
            this.txtByAdmin.TabIndex = 8;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(304, 394);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(51, 13);
            this.label49.TabIndex = 237;
            this.label49.Text = "By.Admin";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(114, 476);
            this.textBox32.Margin = new System.Windows.Forms.Padding(2);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(123, 20);
            this.textBox32.TabIndex = 236;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(25, 477);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(88, 13);
            this.label48.TabIndex = 235;
            this.label48.Text = "Jumlah Angsuran";
            // 
            // txtjlhbunga
            // 
            this.txtjlhbunga.Location = new System.Drawing.Point(114, 449);
            this.txtjlhbunga.Margin = new System.Windows.Forms.Padding(2);
            this.txtjlhbunga.Name = "txtjlhbunga";
            this.txtjlhbunga.Size = new System.Drawing.Size(120, 20);
            this.txtjlhbunga.TabIndex = 6;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(37, 451);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(74, 13);
            this.label46.TabIndex = 231;
            this.label46.Text = "Jumlah Bunga";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(75, 427);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 13);
            this.label45.TabIndex = 229;
            this.label45.Text = "Tenor";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(25, 405);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(86, 13);
            this.label44.TabIndex = 227;
            this.label44.Text = "Jumlah Pinjaman";
            // 
            // rdbBulanan
            // 
            this.rdbBulanan.AutoSize = true;
            this.rdbBulanan.Location = new System.Drawing.Point(242, 376);
            this.rdbBulanan.Margin = new System.Windows.Forms.Padding(2);
            this.rdbBulanan.Name = "rdbBulanan";
            this.rdbBulanan.Size = new System.Drawing.Size(64, 17);
            this.rdbBulanan.TabIndex = 226;
            this.rdbBulanan.TabStop = true;
            this.rdbBulanan.Text = "Bulanan";
            this.rdbBulanan.UseVisualStyleBackColor = true;
            // 
            // rdbMingguan
            // 
            this.rdbMingguan.AutoSize = true;
            this.rdbMingguan.Location = new System.Drawing.Point(173, 376);
            this.rdbMingguan.Margin = new System.Windows.Forms.Padding(2);
            this.rdbMingguan.Name = "rdbMingguan";
            this.rdbMingguan.Size = new System.Drawing.Size(72, 17);
            this.rdbMingguan.TabIndex = 225;
            this.rdbMingguan.TabStop = true;
            this.rdbMingguan.Text = "Mingguan";
            this.rdbMingguan.UseVisualStyleBackColor = true;
            // 
            // rdbHarian
            // 
            this.rdbHarian.AutoSize = true;
            this.rdbHarian.Location = new System.Drawing.Point(116, 376);
            this.rdbHarian.Margin = new System.Windows.Forms.Padding(2);
            this.rdbHarian.Name = "rdbHarian";
            this.rdbHarian.Size = new System.Drawing.Size(56, 17);
            this.rdbHarian.TabIndex = 3;
            this.rdbHarian.TabStop = true;
            this.rdbHarian.Text = "Harian";
            this.rdbHarian.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(39, 376);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(74, 13);
            this.label43.TabIndex = 223;
            this.label43.Text = "Tipe Pinjaman";
            // 
            // txtNoAnggota
            // 
            this.txtNoAnggota.Location = new System.Drawing.Point(114, 2);
            this.txtNoAnggota.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoAnggota.Multiline = true;
            this.txtNoAnggota.Name = "txtNoAnggota";
            this.txtNoAnggota.Size = new System.Drawing.Size(193, 28);
            this.txtNoAnggota.TabIndex = 1;
            this.txtNoAnggota.TextChanged += new System.EventHandler(this.txtNoAnggota_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 141;
            this.label2.Text = "No Anggota";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(31, 461);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(259, 13);
            this.label47.TabIndex = 233;
            this.label47.Text = "__________________________________________";
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(307, 1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(52, 29);
            this.button3.TabIndex = 2;
            this.button3.Text = "Cari";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ds_data
            // 
            this.ds_data.DataSetName = "NewDataSet";
            this.ds_data.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2,
            this.dataTable3,
            this.dataTable4});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27});
            this.dataTable1.TableName = "NASABAH";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NO_KTP";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "NO_KK";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AGAMA";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "JK";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TELP";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PEKERJAAN";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "NAMA_BANK";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "NO_REKENING";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "NAMA_SALES";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "STATUS_APPL";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36});
            this.dataTable2.TableName = "JAMINAN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "KET1";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "KET2";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "NAMA_COLLECTOR";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(49, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 265;
            this.label11.Text = "No KK";
            // 
            // txtNomorKK
            // 
            this.txtNomorKK.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NO_KK", true));
            this.txtNomorKK.Location = new System.Drawing.Point(91, 61);
            this.txtNomorKK.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomorKK.Name = "txtNomorKK";
            this.txtNomorKK.Size = new System.Drawing.Size(244, 20);
            this.txtNomorKK.TabIndex = 257;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 45);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 264;
            this.label12.Text = "No KTP";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 19);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 13);
            this.label13.TabIndex = 263;
            this.label13.Text = "Nama Customer";
            // 
            // txtNomorKTP
            // 
            this.txtNomorKTP.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NO_KTP", true));
            this.txtNomorKTP.Location = new System.Drawing.Point(91, 40);
            this.txtNomorKTP.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomorKTP.Name = "txtNomorKTP";
            this.txtNomorKTP.Size = new System.Drawing.Size(244, 20);
            this.txtNomorKTP.TabIndex = 256;
            // 
            // txtNamaCustomer
            // 
            this.txtNamaCustomer.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NAMA_COSTUMER", true));
            this.txtNamaCustomer.Location = new System.Drawing.Point(91, 18);
            this.txtNamaCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaCustomer.Name = "txtNamaCustomer";
            this.txtNamaCustomer.Size = new System.Drawing.Size(244, 20);
            this.txtNamaCustomer.TabIndex = 255;
            this.txtNamaCustomer.TextChanged += new System.EventHandler(this.txtNamaCustomer_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(33, 159);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 277;
            this.label14.Text = "Pekerjaan";
            // 
            // txtPekerjaan
            // 
            this.txtPekerjaan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.PEKERJAAN", true));
            this.txtPekerjaan.Location = new System.Drawing.Point(92, 155);
            this.txtPekerjaan.Margin = new System.Windows.Forms.Padding(2);
            this.txtPekerjaan.Name = "txtPekerjaan";
            this.txtPekerjaan.Size = new System.Drawing.Size(244, 20);
            this.txtPekerjaan.TabIndex = 273;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(11, 109);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 13);
            this.label23.TabIndex = 276;
            this.label23.Text = "Alamat Domisili";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(25, 87);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 13);
            this.label15.TabIndex = 275;
            this.label15.Text = "Alamat KTP";
            // 
            // txtAlamatDomisili
            // 
            this.txtAlamatDomisili.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.ALAMAT_DOMISILI", true));
            this.txtAlamatDomisili.Location = new System.Drawing.Point(92, 109);
            this.txtAlamatDomisili.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatDomisili.Name = "txtAlamatDomisili";
            this.txtAlamatDomisili.Size = new System.Drawing.Size(244, 20);
            this.txtAlamatDomisili.TabIndex = 271;
            // 
            // txtAlamatKTp
            // 
            this.txtAlamatKTp.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.ALAMAT_KTP", true));
            this.txtAlamatKTp.Location = new System.Drawing.Point(92, 85);
            this.txtAlamatKTp.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatKTp.Name = "txtAlamatKTp";
            this.txtAlamatKTp.Size = new System.Drawing.Size(244, 20);
            this.txtAlamatKTp.TabIndex = 270;
            // 
            // txtTelp
            // 
            this.txtTelp.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.TELP", true));
            this.txtTelp.Location = new System.Drawing.Point(92, 132);
            this.txtTelp.Margin = new System.Windows.Forms.Padding(2);
            this.txtTelp.Name = "txtTelp";
            this.txtTelp.Size = new System.Drawing.Size(244, 20);
            this.txtTelp.TabIndex = 272;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(37, 132);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 13);
            this.label24.TabIndex = 274;
            this.label24.Text = "Telp./HP";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(346, 137);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(90, 13);
            this.label27.TabIndex = 283;
            this.label27.Text = "Tanggal Lahir Ibu";
            // 
            // txtTanggalLahirIbu
            // 
            this.txtTanggalLahirIbu.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.TANGGAL_LAHIR_IBU", true));
            this.txtTanggalLahirIbu.Location = new System.Drawing.Point(443, 135);
            this.txtTanggalLahirIbu.Margin = new System.Windows.Forms.Padding(2);
            this.txtTanggalLahirIbu.Name = "txtTanggalLahirIbu";
            this.txtTanggalLahirIbu.Size = new System.Drawing.Size(177, 20);
            this.txtTanggalLahirIbu.TabIndex = 279;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(337, 111);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(99, 13);
            this.label25.TabIndex = 282;
            this.label25.Text = "Nama Ibu Kandung";
            // 
            // txtNamaIbuKandung
            // 
            this.txtNamaIbuKandung.BackColor = System.Drawing.SystemColors.Window;
            this.txtNamaIbuKandung.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NAMA_IBU_KANDUNG", true));
            this.txtNamaIbuKandung.Location = new System.Drawing.Point(443, 111);
            this.txtNamaIbuKandung.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaIbuKandung.Name = "txtNamaIbuKandung";
            this.txtNamaIbuKandung.Size = new System.Drawing.Size(177, 20);
            this.txtNamaIbuKandung.TabIndex = 278;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(399, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 281;
            this.label3.Text = "Status";
            // 
            // txtJenisUsaha
            // 
            this.txtJenisUsaha.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.JENIS_USAHA", true));
            this.txtJenisUsaha.Location = new System.Drawing.Point(443, 87);
            this.txtJenisUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtJenisUsaha.Name = "txtJenisUsaha";
            this.txtJenisUsaha.Size = new System.Drawing.Size(177, 20);
            this.txtJenisUsaha.TabIndex = 286;
            this.txtJenisUsaha.Text = "21";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 93);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 289;
            this.label7.Text = "Jenis Usaha";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(363, 69);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 288;
            this.label4.Text = "Alamat Usaha";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(367, 48);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 287;
            this.label5.Text = "Nama Usaha";
            // 
            // txtAlamatUsaha
            // 
            this.txtAlamatUsaha.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.ALAMAT_UsAHA", true));
            this.txtAlamatUsaha.Location = new System.Drawing.Point(443, 66);
            this.txtAlamatUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatUsaha.Name = "txtAlamatUsaha";
            this.txtAlamatUsaha.Size = new System.Drawing.Size(177, 20);
            this.txtAlamatUsaha.TabIndex = 285;
            // 
            // txtNamaUsaha
            // 
            this.txtNamaUsaha.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NAMA_USAHA", true));
            this.txtNamaUsaha.Location = new System.Drawing.Point(443, 42);
            this.txtNamaUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaUsaha.Name = "txtNamaUsaha";
            this.txtNamaUsaha.Size = new System.Drawing.Size(177, 20);
            this.txtNamaUsaha.TabIndex = 284;
            // 
            // DetailPasangan
            // 
            this.DetailPasangan.Controls.Add(this.txtnamapasangan);
            this.DetailPasangan.Controls.Add(this.label28);
            this.DetailPasangan.Controls.Add(this.txtnoktppasangan);
            this.DetailPasangan.Controls.Add(this.label29);
            this.DetailPasangan.Controls.Add(this.txtalamatpasangan);
            this.DetailPasangan.Controls.Add(this.label30);
            this.DetailPasangan.Controls.Add(this.txtnotelppasangan);
            this.DetailPasangan.Controls.Add(this.label36);
            this.DetailPasangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DetailPasangan.Location = new System.Drawing.Point(640, 40);
            this.DetailPasangan.Name = "DetailPasangan";
            this.DetailPasangan.Size = new System.Drawing.Size(339, 121);
            this.DetailPasangan.TabIndex = 290;
            this.DetailPasangan.TabStop = false;
            this.DetailPasangan.Visible = false;
            // 
            // txtnamapasangan
            // 
            this.txtnamapasangan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NAMA_PASANGAN", true));
            this.txtnamapasangan.Location = new System.Drawing.Point(95, 18);
            this.txtnamapasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnamapasangan.Name = "txtnamapasangan";
            this.txtnamapasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnamapasangan.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(5, 18);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 13);
            this.label28.TabIndex = 213;
            this.label28.Text = "Nama Pasangan";
            // 
            // txtnoktppasangan
            // 
            this.txtnoktppasangan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.NO_KTP_PASANGAN", true));
            this.txtnoktppasangan.Location = new System.Drawing.Point(95, 41);
            this.txtnoktppasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnoktppasangan.Name = "txtnoktppasangan";
            this.txtnoktppasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnoktppasangan.TabIndex = 2;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(46, 43);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 13);
            this.label29.TabIndex = 215;
            this.label29.Text = "No KTP";
            // 
            // txtalamatpasangan
            // 
            this.txtalamatpasangan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.ALAMAT_PASANGAN", true));
            this.txtalamatpasangan.Location = new System.Drawing.Point(95, 63);
            this.txtalamatpasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtalamatpasangan.Name = "txtalamatpasangan";
            this.txtalamatpasangan.Size = new System.Drawing.Size(224, 20);
            this.txtalamatpasangan.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(52, 63);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 13);
            this.label30.TabIndex = 217;
            this.label30.Text = "Alamat";
            // 
            // txtnotelppasangan
            // 
            this.txtnotelppasangan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.ALAMAT_PASANGAN", true));
            this.txtnotelppasangan.Location = new System.Drawing.Point(95, 88);
            this.txtnotelppasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnotelppasangan.Name = "txtnotelppasangan";
            this.txtnotelppasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnotelppasangan.TabIndex = 4;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(23, 90);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(68, 13);
            this.label36.TabIndex = 230;
            this.label36.Text = "No. Telp/HP";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(23, 221);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(989, 152);
            this.groupBox1.TabIndex = 100;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "JAMINAN";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(977, 127);
            this.dataGridView1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_data, "NASABAH.STATUS_MENIKAH", true));
            this.textBox1.Location = new System.Drawing.Point(443, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 292;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.txtNamaCustomer);
            this.groupBox2.Controls.Add(this.txtNomorKTP);
            this.groupBox2.Controls.Add(this.DetailPasangan);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtJenisUsaha);
            this.groupBox2.Controls.Add(this.txtNomorKK);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtTelp);
            this.groupBox2.Controls.Add(this.txtAlamatUsaha);
            this.groupBox2.Controls.Add(this.txtAlamatKTp);
            this.groupBox2.Controls.Add(this.txtNamaUsaha);
            this.groupBox2.Controls.Add(this.txtAlamatDomisili);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtTanggalLahirIbu);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtPekerjaan);
            this.groupBox2.Controls.Add(this.txtNamaIbuKandung);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(23, 32);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(983, 184);
            this.groupBox2.TabIndex = 99;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DETAIL ANGGOTA";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn37,
            this.dataColumn38});
            this.dataTable3.TableName = "SALES";
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "SALES_ID";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "NM_SALES";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn39});
            this.dataTable4.TableName = "COLLECTOR";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "NM_COLLECTOR";
            // 
            // nudJlhPinjaman
            // 
            this.nudJlhPinjaman.Location = new System.Drawing.Point(114, 403);
            this.nudJlhPinjaman.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.nudJlhPinjaman.Name = "nudJlhPinjaman";
            this.nudJlhPinjaman.Size = new System.Drawing.Size(120, 20);
            this.nudJlhPinjaman.TabIndex = 4;
            this.nudJlhPinjaman.ThousandsSeparator = true;
            // 
            // nudTenor
            // 
            this.nudTenor.Location = new System.Drawing.Point(114, 425);
            this.nudTenor.Name = "nudTenor";
            this.nudTenor.Size = new System.Drawing.Size(120, 20);
            this.nudTenor.TabIndex = 5;
            // 
            // txtjlhbnga
            // 
            this.txtjlhbnga.Location = new System.Drawing.Point(240, 449);
            this.txtjlhbnga.Name = "txtjlhbnga";
            this.txtjlhbnga.Size = new System.Drawing.Size(45, 20);
            this.txtjlhbnga.TabIndex = 7;
            // 
            // txtSuveryor
            // 
            this.txtSuveryor.Location = new System.Drawing.Point(359, 414);
            this.txtSuveryor.Name = "txtSuveryor";
            this.txtSuveryor.Size = new System.Drawing.Size(123, 20);
            this.txtSuveryor.TabIndex = 9;
            // 
            // F050105
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtSuveryor);
            this.Controls.Add(this.txtjlhbnga);
            this.Controls.Add(this.nudTenor);
            this.Controls.Add(this.nudJlhPinjaman);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.namasales);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.txtKet);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.txtLokasiTagih);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.cbxGrup);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.cbxCollector);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.txtByAdmin);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.txtjlhbunga);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.rdbBulanan);
            this.Controls.Add(this.rdbMingguan);
            this.Controls.Add(this.rdbHarian);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.txtNoAnggota);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label47);
            this.Name = "F050105";
            this.Size = new System.Drawing.Size(1067, 658);
            this.Load += new System.EventHandler(this.F050105_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            this.DetailPasangan.ResumeLayout(false);
            this.DetailPasangan.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJlhPinjaman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox namasales;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtKet;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtLokasiTagih;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox cbxGrup;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox cbxCollector;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtByAdmin;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtjlhbunga;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RadioButton rdbBulanan;
        private System.Windows.Forms.RadioButton rdbMingguan;
        private System.Windows.Forms.RadioButton rdbHarian;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.TextBox txtNoAnggota;
        public System.Windows.Forms.Timer timer1;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        public System.Data.DataSet ds_data;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNomorKK;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNomorKTP;
        private System.Windows.Forms.TextBox txtNamaCustomer;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtPekerjaan;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAlamatDomisili;
        private System.Windows.Forms.TextBox txtAlamatKTp;
        private System.Windows.Forms.TextBox txtTelp;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtTanggalLahirIbu;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtNamaIbuKandung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtJenisUsaha;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAlamatUsaha;
        private System.Windows.Forms.TextBox txtNamaUsaha;
        private System.Windows.Forms.GroupBox DetailPasangan;
        private System.Windows.Forms.TextBox txtnamapasangan;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtnoktppasangan;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtalamatpasangan;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtnotelppasangan;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn39;
        private System.Windows.Forms.NumericUpDown nudJlhPinjaman;
        private System.Windows.Forms.NumericUpDown nudTenor;
        private System.Windows.Forms.TextBox txtjlhbnga;
        private System.Windows.Forms.TextBox txtSuveryor;
    }
}
