﻿namespace Management
{
    partial class F050106
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNamaAnggota = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtjlhbnga = new System.Windows.Forms.TextBox();
            this.nudTenor = new System.Windows.Forms.NumericUpDown();
            this.nudJlhPinjaman = new System.Windows.Forms.NumericUpDown();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtjlhbunga = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.ds_data = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn44 = new System.Data.DataColumn();
            this.dataColumn45 = new System.Data.DataColumn();
            this.dataColumn46 = new System.Data.DataColumn();
            this.dataColumn47 = new System.Data.DataColumn();
            this.dataColumn48 = new System.Data.DataColumn();
            this.dataColumn49 = new System.Data.DataColumn();
            this.ds_single1 = new System.Data.DataSet();
            this.dataTable5 = new System.Data.DataTable();
            this.dataColumn50 = new System.Data.DataColumn();
            this.dataColumn51 = new System.Data.DataColumn();
            this.dataColumn52 = new System.Data.DataColumn();
            this.dataColumn53 = new System.Data.DataColumn();
            this.dataColumn54 = new System.Data.DataColumn();
            this.dataColumn55 = new System.Data.DataColumn();
            this.dataColumn56 = new System.Data.DataColumn();
            this.dataColumn57 = new System.Data.DataColumn();
            this.dataColumn58 = new System.Data.DataColumn();
            this.dataColumn59 = new System.Data.DataColumn();
            this.dataColumn60 = new System.Data.DataColumn();
            this.dataColumn61 = new System.Data.DataColumn();
            this.dataColumn62 = new System.Data.DataColumn();
            this.dataColumn63 = new System.Data.DataColumn();
            this.dataColumn64 = new System.Data.DataColumn();
            this.dataColumn65 = new System.Data.DataColumn();
            this.dataColumn66 = new System.Data.DataColumn();
            this.dataColumn67 = new System.Data.DataColumn();
            this.dataColumn68 = new System.Data.DataColumn();
            this.dataColumn69 = new System.Data.DataColumn();
            this.dataColumn70 = new System.Data.DataColumn();
            this.dataColumn71 = new System.Data.DataColumn();
            this.dataColumn72 = new System.Data.DataColumn();
            this.dataColumn73 = new System.Data.DataColumn();
            this.dataColumn74 = new System.Data.DataColumn();
            this.dataColumn75 = new System.Data.DataColumn();
            this.dataColumn76 = new System.Data.DataColumn();
            this.dataTable6 = new System.Data.DataTable();
            this.dataColumn77 = new System.Data.DataColumn();
            this.dataColumn78 = new System.Data.DataColumn();
            this.dataColumn79 = new System.Data.DataColumn();
            this.dataColumn80 = new System.Data.DataColumn();
            this.dataColumn81 = new System.Data.DataColumn();
            this.dataColumn82 = new System.Data.DataColumn();
            this.dataColumn83 = new System.Data.DataColumn();
            this.dataColumn84 = new System.Data.DataColumn();
            this.dataColumn85 = new System.Data.DataColumn();
            this.dataTable7 = new System.Data.DataTable();
            this.dataColumn86 = new System.Data.DataColumn();
            this.dataColumn87 = new System.Data.DataColumn();
            this.dataColumn88 = new System.Data.DataColumn();
            this.dataColumn89 = new System.Data.DataColumn();
            this.dataColumn90 = new System.Data.DataColumn();
            this.dataColumn91 = new System.Data.DataColumn();
            this.dataColumn92 = new System.Data.DataColumn();
            this.dataTable8 = new System.Data.DataTable();
            this.dataColumn93 = new System.Data.DataColumn();
            this.dataColumn94 = new System.Data.DataColumn();
            this.dataColumn95 = new System.Data.DataColumn();
            this.dataColumn96 = new System.Data.DataColumn();
            this.dataColumn97 = new System.Data.DataColumn();
            this.dataColumn98 = new System.Data.DataColumn();
            this.dataColumn99 = new System.Data.DataColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJlhPinjaman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_single1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable8)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nama Anggota";
            // 
            // txtNamaAnggota
            // 
            this.txtNamaAnggota.Location = new System.Drawing.Point(87, 3);
            this.txtNamaAnggota.Multiline = true;
            this.txtNamaAnggota.Name = "txtNamaAnggota";
            this.txtNamaAnggota.Size = new System.Drawing.Size(188, 28);
            this.txtNamaAnggota.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(272, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(51, 28);
            this.button1.TabIndex = 2;
            this.button1.Text = "Cari";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 59);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(723, 273);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txtjlhbnga
            // 
            this.txtjlhbnga.Location = new System.Drawing.Point(232, 386);
            this.txtjlhbnga.Name = "txtjlhbnga";
            this.txtjlhbnga.Size = new System.Drawing.Size(45, 20);
            this.txtjlhbnga.TabIndex = 240;
            // 
            // nudTenor
            // 
            this.nudTenor.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ds_single1, "PINJAMAN.JLH_TENOR", true));
            this.nudTenor.Location = new System.Drawing.Point(106, 362);
            this.nudTenor.Name = "nudTenor";
            this.nudTenor.Size = new System.Drawing.Size(120, 20);
            this.nudTenor.TabIndex = 238;
            // 
            // nudJlhPinjaman
            // 
            this.nudJlhPinjaman.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ds_single1, "PINJAMAN.JLH_PINJAMAN", true));
            this.nudJlhPinjaman.Location = new System.Drawing.Point(106, 340);
            this.nudJlhPinjaman.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.nudJlhPinjaman.Name = "nudJlhPinjaman";
            this.nudJlhPinjaman.Size = new System.Drawing.Size(120, 20);
            this.nudJlhPinjaman.TabIndex = 237;
            this.nudJlhPinjaman.ThousandsSeparator = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(15, 437);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(124, 31);
            this.button2.TabIndex = 241;
            this.button2.Text = "Simpan";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(106, 413);
            this.textBox32.Margin = new System.Windows.Forms.Padding(2);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(123, 20);
            this.textBox32.TabIndex = 247;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(17, 414);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(88, 13);
            this.label48.TabIndex = 246;
            this.label48.Text = "Jumlah Angsuran";
            // 
            // txtjlhbunga
            // 
            this.txtjlhbunga.Location = new System.Drawing.Point(106, 386);
            this.txtjlhbunga.Margin = new System.Windows.Forms.Padding(2);
            this.txtjlhbunga.Name = "txtjlhbunga";
            this.txtjlhbunga.Size = new System.Drawing.Size(120, 20);
            this.txtjlhbunga.TabIndex = 239;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(29, 388);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(74, 13);
            this.label46.TabIndex = 244;
            this.label46.Text = "Jumlah Bunga";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(67, 364);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 13);
            this.label45.TabIndex = 243;
            this.label45.Text = "Tenor";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(17, 342);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(86, 13);
            this.label44.TabIndex = 242;
            this.label44.Text = "Jumlah Pinjaman";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(23, 398);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(259, 13);
            this.label47.TabIndex = 245;
            this.label47.Text = "__________________________________________";
            // 
            // ds_data
            // 
            this.ds_data.DataSetName = "NewDataSet";
            this.ds_data.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2,
            this.dataTable3,
            this.dataTable4});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27});
            this.dataTable1.TableName = "NASABAH";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NO_KTP";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "NO_KK";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AGAMA";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "JK";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TELP";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PEKERJAAN";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "NAMA_BANK";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "NO_REKENING";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "NAMA_SALES";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "STATUS_APPL";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36});
            this.dataTable2.TableName = "JAMINAN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "KET1";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "KET2";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "NAMA_COLLECTOR";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn37,
            this.dataColumn38,
            this.dataColumn39,
            this.dataColumn40,
            this.dataColumn42,
            this.dataColumn41,
            this.dataColumn43});
            this.dataTable3.TableName = "SALES";
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "Stts";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "Chk";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "SALES_ID";
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "NM_SALES";
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "TELP_SALES";
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "ALAMAT_SALES";
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "IS_ACTIVE";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn44,
            this.dataColumn45,
            this.dataColumn46,
            this.dataColumn47,
            this.dataColumn48,
            this.dataColumn49});
            this.dataTable4.TableName = "PINJAMAN";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "NM_NASABAH";
            // 
            // dataColumn45
            // 
            this.dataColumn45.ColumnName = "NM_SALES";
            // 
            // dataColumn46
            // 
            this.dataColumn46.ColumnName = "NM_COLLECTOR";
            // 
            // dataColumn47
            // 
            this.dataColumn47.ColumnName = "JLH_PINJAMAN";
            // 
            // dataColumn48
            // 
            this.dataColumn48.ColumnName = "TIPE_PINJAMAN";
            // 
            // dataColumn49
            // 
            this.dataColumn49.ColumnName = "id";
            // 
            // ds_single1
            // 
            this.ds_single1.DataSetName = "NewDataSet";
            this.ds_single1.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable5,
            this.dataTable6,
            this.dataTable7,
            this.dataTable8});
            // 
            // dataTable5
            // 
            this.dataTable5.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn50,
            this.dataColumn51,
            this.dataColumn52,
            this.dataColumn53,
            this.dataColumn54,
            this.dataColumn55,
            this.dataColumn56,
            this.dataColumn57,
            this.dataColumn58,
            this.dataColumn59,
            this.dataColumn60,
            this.dataColumn61,
            this.dataColumn62,
            this.dataColumn63,
            this.dataColumn64,
            this.dataColumn65,
            this.dataColumn66,
            this.dataColumn67,
            this.dataColumn68,
            this.dataColumn69,
            this.dataColumn70,
            this.dataColumn71,
            this.dataColumn72,
            this.dataColumn73,
            this.dataColumn74,
            this.dataColumn75,
            this.dataColumn76});
            this.dataTable5.TableName = "NASABAH";
            // 
            // dataColumn50
            // 
            this.dataColumn50.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn51
            // 
            this.dataColumn51.ColumnName = "NO_KTP";
            // 
            // dataColumn52
            // 
            this.dataColumn52.ColumnName = "NO_KK";
            // 
            // dataColumn53
            // 
            this.dataColumn53.ColumnName = "AGAMA";
            // 
            // dataColumn54
            // 
            this.dataColumn54.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn55
            // 
            this.dataColumn55.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn56
            // 
            this.dataColumn56.ColumnName = "JK";
            // 
            // dataColumn57
            // 
            this.dataColumn57.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn58
            // 
            this.dataColumn58.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn59
            // 
            this.dataColumn59.ColumnName = "TELP";
            // 
            // dataColumn60
            // 
            this.dataColumn60.ColumnName = "PEKERJAAN";
            // 
            // dataColumn61
            // 
            this.dataColumn61.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn62
            // 
            this.dataColumn62.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn63
            // 
            this.dataColumn63.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn64
            // 
            this.dataColumn64.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn65
            // 
            this.dataColumn65.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn66
            // 
            this.dataColumn66.ColumnName = "NAMA_BANK";
            // 
            // dataColumn67
            // 
            this.dataColumn67.ColumnName = "NO_REKENING";
            // 
            // dataColumn68
            // 
            this.dataColumn68.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn69
            // 
            this.dataColumn69.ColumnName = "NAMA_SALES";
            // 
            // dataColumn70
            // 
            this.dataColumn70.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn71
            // 
            this.dataColumn71.ColumnName = "STATUS_APPL";
            // 
            // dataColumn72
            // 
            this.dataColumn72.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn73
            // 
            this.dataColumn73.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn74
            // 
            this.dataColumn74.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn75
            // 
            this.dataColumn75.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn76
            // 
            this.dataColumn76.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable6
            // 
            this.dataTable6.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn77,
            this.dataColumn78,
            this.dataColumn79,
            this.dataColumn80,
            this.dataColumn81,
            this.dataColumn82,
            this.dataColumn83,
            this.dataColumn84,
            this.dataColumn85});
            this.dataTable6.TableName = "JAMINAN";
            // 
            // dataColumn77
            // 
            this.dataColumn77.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn78
            // 
            this.dataColumn78.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn79
            // 
            this.dataColumn79.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn80
            // 
            this.dataColumn80.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn81
            // 
            this.dataColumn81.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn82
            // 
            this.dataColumn82.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn83
            // 
            this.dataColumn83.ColumnName = "KET1";
            // 
            // dataColumn84
            // 
            this.dataColumn84.ColumnName = "KET2";
            // 
            // dataColumn85
            // 
            this.dataColumn85.ColumnName = "NAMA_COLLECTOR";
            // 
            // dataTable7
            // 
            this.dataTable7.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn86,
            this.dataColumn87,
            this.dataColumn88,
            this.dataColumn89,
            this.dataColumn90,
            this.dataColumn91,
            this.dataColumn92});
            this.dataTable7.TableName = "SALES";
            // 
            // dataColumn86
            // 
            this.dataColumn86.ColumnName = "Stts";
            // 
            // dataColumn87
            // 
            this.dataColumn87.ColumnName = "Chk";
            // 
            // dataColumn88
            // 
            this.dataColumn88.ColumnName = "SALES_ID";
            // 
            // dataColumn89
            // 
            this.dataColumn89.ColumnName = "NM_SALES";
            // 
            // dataColumn90
            // 
            this.dataColumn90.ColumnName = "TELP_SALES";
            // 
            // dataColumn91
            // 
            this.dataColumn91.ColumnName = "ALAMAT_SALES";
            // 
            // dataColumn92
            // 
            this.dataColumn92.ColumnName = "IS_ACTIVE";
            // 
            // dataTable8
            // 
            this.dataTable8.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn93,
            this.dataColumn94,
            this.dataColumn95,
            this.dataColumn96,
            this.dataColumn97,
            this.dataColumn98,
            this.dataColumn99});
            this.dataTable8.TableName = "PINJAMAN";
            // 
            // dataColumn93
            // 
            this.dataColumn93.ColumnName = "NM_NASABAH";
            // 
            // dataColumn94
            // 
            this.dataColumn94.ColumnName = "NM_SALES";
            // 
            // dataColumn95
            // 
            this.dataColumn95.ColumnName = "NM_COLLECTOR";
            // 
            // dataColumn96
            // 
            this.dataColumn96.ColumnName = "JLH_PINJAMAN";
            // 
            // dataColumn97
            // 
            this.dataColumn97.ColumnName = "TIPE_PINJAMAN";
            // 
            // dataColumn98
            // 
            this.dataColumn98.ColumnName = "JLH_TENOR";
            // 
            // dataColumn99
            // 
            this.dataColumn99.ColumnName = "id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(287, 341);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 248;
            this.label2.Text = "id";
            // 
            // txtID
            // 
            this.txtID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ds_single1, "PINJAMAN.id", true));
            this.txtID.Enabled = false;
            this.txtID.Location = new System.Drawing.Point(308, 340);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(100, 20);
            this.txtID.TabIndex = 249;
            // 
            // F050106
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtjlhbnga);
            this.Controls.Add(this.nudTenor);
            this.Controls.Add(this.nudJlhPinjaman);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.txtjlhbunga);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtNamaAnggota);
            this.Controls.Add(this.label1);
            this.Name = "F050106";
            this.Size = new System.Drawing.Size(769, 497);
            this.Load += new System.EventHandler(this.F050106_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTenor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJlhPinjaman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_single1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNamaAnggota;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtjlhbnga;
        private System.Windows.Forms.NumericUpDown nudTenor;
        private System.Windows.Forms.NumericUpDown nudJlhPinjaman;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtjlhbunga;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        public System.Data.DataSet ds_data;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn44;
        private System.Data.DataColumn dataColumn45;
        private System.Data.DataColumn dataColumn46;
        private System.Data.DataColumn dataColumn47;
        private System.Data.DataColumn dataColumn48;
        private System.Data.DataColumn dataColumn49;
        public System.Data.DataSet ds_single1;
        private System.Data.DataTable dataTable5;
        private System.Data.DataColumn dataColumn50;
        private System.Data.DataColumn dataColumn51;
        private System.Data.DataColumn dataColumn52;
        private System.Data.DataColumn dataColumn53;
        private System.Data.DataColumn dataColumn54;
        private System.Data.DataColumn dataColumn55;
        private System.Data.DataColumn dataColumn56;
        private System.Data.DataColumn dataColumn57;
        private System.Data.DataColumn dataColumn58;
        private System.Data.DataColumn dataColumn59;
        private System.Data.DataColumn dataColumn60;
        private System.Data.DataColumn dataColumn61;
        private System.Data.DataColumn dataColumn62;
        private System.Data.DataColumn dataColumn63;
        private System.Data.DataColumn dataColumn64;
        private System.Data.DataColumn dataColumn65;
        private System.Data.DataColumn dataColumn66;
        private System.Data.DataColumn dataColumn67;
        private System.Data.DataColumn dataColumn68;
        private System.Data.DataColumn dataColumn69;
        private System.Data.DataColumn dataColumn70;
        private System.Data.DataColumn dataColumn71;
        private System.Data.DataColumn dataColumn72;
        private System.Data.DataColumn dataColumn73;
        private System.Data.DataColumn dataColumn74;
        private System.Data.DataColumn dataColumn75;
        private System.Data.DataColumn dataColumn76;
        private System.Data.DataTable dataTable6;
        private System.Data.DataColumn dataColumn77;
        private System.Data.DataColumn dataColumn78;
        private System.Data.DataColumn dataColumn79;
        private System.Data.DataColumn dataColumn80;
        private System.Data.DataColumn dataColumn81;
        private System.Data.DataColumn dataColumn82;
        private System.Data.DataColumn dataColumn83;
        private System.Data.DataColumn dataColumn84;
        private System.Data.DataColumn dataColumn85;
        private System.Data.DataTable dataTable7;
        private System.Data.DataColumn dataColumn86;
        private System.Data.DataColumn dataColumn87;
        private System.Data.DataColumn dataColumn88;
        private System.Data.DataColumn dataColumn89;
        private System.Data.DataColumn dataColumn90;
        private System.Data.DataColumn dataColumn91;
        private System.Data.DataColumn dataColumn92;
        private System.Data.DataTable dataTable8;
        private System.Data.DataColumn dataColumn93;
        private System.Data.DataColumn dataColumn94;
        private System.Data.DataColumn dataColumn95;
        private System.Data.DataColumn dataColumn96;
        private System.Data.DataColumn dataColumn97;
        private System.Data.DataColumn dataColumn98;
        private System.Data.DataColumn dataColumn99;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtID;
    }
}
