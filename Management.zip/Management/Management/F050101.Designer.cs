﻿namespace Management
{
    partial class F050101
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label36 = new System.Windows.Forms.Label();
            this.txtnotelppasangan = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtNomorTelepon = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtalamatpasangan = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtnoktppasangan = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtnamapasangan = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtTanggalLahirIbu = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtPekerjaan = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtNamaIbuKandung = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dtmTanggalLahir = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.txtTempatLahir = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtNomorKK = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtNoAnggota = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtNamarek = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNoRek = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNamaBank = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAlamatDomisili = new System.Windows.Forms.TextBox();
            this.txtAlamatKTp = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTelp = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtJenisUsaha = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAlamatUsaha = new System.Windows.Forms.TextBox();
            this.txtNamaUsaha = new System.Windows.Forms.TextBox();
            this.txtNomorKTP = new System.Windows.Forms.TextBox();
            this.txtNamaCustomer = new System.Windows.Forms.TextBox();
            this.cbxAgama = new System.Windows.Forms.ComboBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.status = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.DetailPasangan = new System.Windows.Forms.GroupBox();
            this.areatagis = new System.Windows.Forms.TextBox();
            this.statusappl = new System.Windows.Forms.GroupBox();
            this.rdbsttsaplro = new System.Windows.Forms.RadioButton();
            this.rdbsttsaplnew = new System.Windows.Forms.RadioButton();
            this.Prov = new System.Windows.Forms.TextBox();
            this.Kab = new System.Windows.Forms.TextBox();
            this.Kec = new System.Windows.Forms.TextBox();
            this.ds_data = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn44 = new System.Data.DataColumn();
            this.namasales = new System.Windows.Forms.ComboBox();
            this.status.SuspendLayout();
            this.DetailPasangan.SuspendLayout();
            this.statusappl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            this.SuspendLayout();
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(23, 90);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(68, 13);
            this.label36.TabIndex = 230;
            this.label36.Text = "No. Telp/HP";
            // 
            // txtnotelppasangan
            // 
            this.txtnotelppasangan.Location = new System.Drawing.Point(95, 88);
            this.txtnotelppasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnotelppasangan.Name = "txtnotelppasangan";
            this.txtnotelppasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnotelppasangan.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(46, 134);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 13);
            this.label35.TabIndex = 226;
            this.label35.Text = "Jenis Klamin";
            // 
            // txtNomorTelepon
            // 
            this.txtNomorTelepon.Location = new System.Drawing.Point(492, 84);
            this.txtNomorTelepon.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomorTelepon.Name = "txtNomorTelepon";
            this.txtNomorTelepon.Size = new System.Drawing.Size(242, 20);
            this.txtNomorTelepon.TabIndex = 22;
            this.txtNomorTelepon.Text = "22";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(423, 83);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(64, 13);
            this.label34.TabIndex = 224;
            this.label34.Text = "No.Telp/Hp";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(650, 45);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 13);
            this.label33.TabIndex = 223;
            this.label33.Text = "Kec.";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(561, 45);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 13);
            this.label32.TabIndex = 221;
            this.label32.Text = "Kab.";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(455, 46);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 13);
            this.label31.TabIndex = 219;
            this.label31.Text = "Prov.";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(52, 63);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 13);
            this.label30.TabIndex = 217;
            this.label30.Text = "Alamat";
            // 
            // txtalamatpasangan
            // 
            this.txtalamatpasangan.Location = new System.Drawing.Point(95, 63);
            this.txtalamatpasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtalamatpasangan.Name = "txtalamatpasangan";
            this.txtalamatpasangan.Size = new System.Drawing.Size(224, 20);
            this.txtalamatpasangan.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(46, 43);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 13);
            this.label29.TabIndex = 215;
            this.label29.Text = "No KTP";
            // 
            // txtnoktppasangan
            // 
            this.txtnoktppasangan.Location = new System.Drawing.Point(95, 41);
            this.txtnoktppasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnoktppasangan.Name = "txtnoktppasangan";
            this.txtnoktppasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnoktppasangan.TabIndex = 2;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(5, 18);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 13);
            this.label28.TabIndex = 213;
            this.label28.Text = "Nama Pasangan";
            // 
            // txtnamapasangan
            // 
            this.txtnamapasangan.Location = new System.Drawing.Point(95, 18);
            this.txtnamapasangan.Margin = new System.Windows.Forms.Padding(2);
            this.txtnamapasangan.Name = "txtnamapasangan";
            this.txtnamapasangan.Size = new System.Drawing.Size(224, 20);
            this.txtnamapasangan.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(21, 270);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(90, 13);
            this.label27.TabIndex = 211;
            this.label27.Text = "Tanggal Lahir Ibu";
            // 
            // txtTanggalLahirIbu
            // 
            this.txtTanggalLahirIbu.Location = new System.Drawing.Point(115, 267);
            this.txtTanggalLahirIbu.Margin = new System.Windows.Forms.Padding(2);
            this.txtTanggalLahirIbu.Name = "txtTanggalLahirIbu";
            this.txtTanggalLahirIbu.Size = new System.Drawing.Size(224, 20);
            this.txtTanggalLahirIbu.TabIndex = 13;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(56, 226);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 13);
            this.label26.TabIndex = 209;
            this.label26.Text = "Pekerjaan";
            // 
            // txtPekerjaan
            // 
            this.txtPekerjaan.Location = new System.Drawing.Point(115, 222);
            this.txtPekerjaan.Margin = new System.Windows.Forms.Padding(2);
            this.txtPekerjaan.Name = "txtPekerjaan";
            this.txtPekerjaan.Size = new System.Drawing.Size(224, 20);
            this.txtPekerjaan.TabIndex = 11;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 247);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(99, 13);
            this.label25.TabIndex = 207;
            this.label25.Text = "Nama Ibu Kandung";
            // 
            // txtNamaIbuKandung
            // 
            this.txtNamaIbuKandung.BackColor = System.Drawing.SystemColors.Window;
            this.txtNamaIbuKandung.Location = new System.Drawing.Point(115, 244);
            this.txtNamaIbuKandung.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaIbuKandung.Name = "txtNamaIbuKandung";
            this.txtNamaIbuKandung.Size = new System.Drawing.Size(224, 20);
            this.txtNamaIbuKandung.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(74, 302);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 13);
            this.label24.TabIndex = 203;
            this.label24.Text = "Status";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(34, 176);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 13);
            this.label23.TabIndex = 202;
            this.label23.Text = "Alamat Domisili";
            // 
            // dtmTanggalLahir
            // 
            this.dtmTanggalLahir.Location = new System.Drawing.Point(267, 111);
            this.dtmTanggalLahir.Margin = new System.Windows.Forms.Padding(2);
            this.dtmTanggalLahir.Name = "dtmTanggalLahir";
            this.dtmTanggalLahir.Size = new System.Drawing.Size(117, 20);
            this.dtmTanggalLahir.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(-2, 111);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 13);
            this.label22.TabIndex = 200;
            this.label22.Text = "Tempat/Tanggal Lahir";
            // 
            // txtTempatLahir
            // 
            this.txtTempatLahir.Location = new System.Drawing.Point(115, 110);
            this.txtTempatLahir.Margin = new System.Windows.Forms.Padding(2);
            this.txtTempatLahir.Name = "txtTempatLahir";
            this.txtTempatLahir.Size = new System.Drawing.Size(148, 20);
            this.txtTempatLahir.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(71, 89);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 13);
            this.label21.TabIndex = 197;
            this.label21.Text = "Agama";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(73, 71);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 13);
            this.label20.TabIndex = 196;
            this.label20.Text = "No KK";
            // 
            // txtNomorKK
            // 
            this.txtNomorKK.Location = new System.Drawing.Point(115, 67);
            this.txtNomorKK.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomorKK.Name = "txtNomorKK";
            this.txtNomorKK.Size = new System.Drawing.Size(224, 20);
            this.txtNomorKK.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(47, 5);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 13);
            this.label19.TabIndex = 194;
            this.label19.Text = "No Anggota";
            // 
            // txtNoAnggota
            // 
            this.txtNoAnggota.Enabled = false;
            this.txtNoAnggota.Location = new System.Drawing.Point(115, 2);
            this.txtNoAnggota.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoAnggota.Name = "txtNoAnggota";
            this.txtNoAnggota.Size = new System.Drawing.Size(224, 20);
            this.txtNoAnggota.TabIndex = 193;
            this.txtNoAnggota.TextChanged += new System.EventHandler(this.txtNoAnggota_TextChanged);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(108, 453);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(70, 30);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "Simpan";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtNamarek
            // 
            this.txtNamarek.Location = new System.Drawing.Point(492, 173);
            this.txtNamarek.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamarek.Name = "txtNamarek";
            this.txtNamarek.Size = new System.Drawing.Size(242, 20);
            this.txtNamarek.TabIndex = 25;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(429, 175);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 188;
            this.label17.Text = "Nama Rek";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(385, 244);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 13);
            this.label13.TabIndex = 187;
            this.label13.Text = "Wilayah/Area Tagih";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(423, 223);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 13);
            this.label12.TabIndex = 186;
            this.label12.Text = "Nama Sales";
            // 
            // txtNoRek
            // 
            this.txtNoRek.Location = new System.Drawing.Point(492, 150);
            this.txtNoRek.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoRek.Name = "txtNoRek";
            this.txtNoRek.Size = new System.Drawing.Size(242, 20);
            this.txtNoRek.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(443, 150);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 184;
            this.label11.Text = "No Rek";
            // 
            // txtNamaBank
            // 
            this.txtNamaBank.Location = new System.Drawing.Point(492, 128);
            this.txtNamaBank.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaBank.Name = "txtNamaBank";
            this.txtNamaBank.Size = new System.Drawing.Size(242, 20);
            this.txtNamaBank.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(424, 130);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 182;
            this.label6.Text = "Nama Bank";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 154);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 181;
            this.label5.Text = "Alamat KTP";
            // 
            // txtAlamatDomisili
            // 
            this.txtAlamatDomisili.Location = new System.Drawing.Point(115, 176);
            this.txtAlamatDomisili.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatDomisili.Name = "txtAlamatDomisili";
            this.txtAlamatDomisili.Size = new System.Drawing.Size(224, 20);
            this.txtAlamatDomisili.TabIndex = 9;
            // 
            // txtAlamatKTp
            // 
            this.txtAlamatKTp.Location = new System.Drawing.Point(115, 152);
            this.txtAlamatKTp.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatKTp.Name = "txtAlamatKTp";
            this.txtAlamatKTp.Size = new System.Drawing.Size(224, 20);
            this.txtAlamatKTp.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(310, -28);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 13);
            this.label10.TabIndex = 178;
            this.label10.Text = "DATA PEMOHON";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(449, 277);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 175;
            this.label9.Text = "Status";
            // 
            // txtTelp
            // 
            this.txtTelp.Location = new System.Drawing.Point(115, 199);
            this.txtTelp.Margin = new System.Windows.Forms.Padding(2);
            this.txtTelp.Name = "txtTelp";
            this.txtTelp.Size = new System.Drawing.Size(224, 20);
            this.txtTelp.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(60, 199);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 173;
            this.label8.Text = "Telp./HP";
            // 
            // txtJenisUsaha
            // 
            this.txtJenisUsaha.Location = new System.Drawing.Point(492, 63);
            this.txtJenisUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtJenisUsaha.Name = "txtJenisUsaha";
            this.txtJenisUsaha.Size = new System.Drawing.Size(242, 20);
            this.txtJenisUsaha.TabIndex = 21;
            this.txtJenisUsaha.Text = "21";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(422, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 171;
            this.label7.Text = "Jenis Usaha";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(414, 24);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 170;
            this.label4.Text = "Alamat Usaha";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(418, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 169;
            this.label3.Text = "Nama Usaha";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 51);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 168;
            this.label2.Text = "No KTP";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 167;
            this.label1.Text = "Nama Customer";
            // 
            // txtAlamatUsaha
            // 
            this.txtAlamatUsaha.Location = new System.Drawing.Point(492, 21);
            this.txtAlamatUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamatUsaha.Name = "txtAlamatUsaha";
            this.txtAlamatUsaha.Size = new System.Drawing.Size(242, 20);
            this.txtAlamatUsaha.TabIndex = 17;
            // 
            // txtNamaUsaha
            // 
            this.txtNamaUsaha.Location = new System.Drawing.Point(492, 1);
            this.txtNamaUsaha.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaUsaha.Name = "txtNamaUsaha";
            this.txtNamaUsaha.Size = new System.Drawing.Size(242, 20);
            this.txtNamaUsaha.TabIndex = 16;
            // 
            // txtNomorKTP
            // 
            this.txtNomorKTP.Location = new System.Drawing.Point(115, 47);
            this.txtNomorKTP.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomorKTP.Name = "txtNomorKTP";
            this.txtNomorKTP.Size = new System.Drawing.Size(224, 20);
            this.txtNomorKTP.TabIndex = 2;
            // 
            // txtNamaCustomer
            // 
            this.txtNamaCustomer.Location = new System.Drawing.Point(115, 24);
            this.txtNamaCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtNamaCustomer.Name = "txtNamaCustomer";
            this.txtNamaCustomer.Size = new System.Drawing.Size(224, 20);
            this.txtNamaCustomer.TabIndex = 1;
            // 
            // cbxAgama
            // 
            this.cbxAgama.FormattingEnabled = true;
            this.cbxAgama.ItemHeight = 13;
            this.cbxAgama.Items.AddRange(new object[] {
            "Islam",
            "Kristen",
            "Budha",
            "Hindu",
            "Konghuchu",
            "Other"});
            this.cbxAgama.Location = new System.Drawing.Point(115, 88);
            this.cbxAgama.Name = "cbxAgama";
            this.cbxAgama.Size = new System.Drawing.Size(224, 21);
            this.cbxAgama.TabIndex = 4;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(113, 132);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(68, 17);
            this.radioButton1.TabIndex = 6;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Laki-Laki";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(187, 132);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(79, 17);
            this.radioButton2.TabIndex = 7;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Perempuan";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // status
            // 
            this.status.Controls.Add(this.radioButton3);
            this.status.Controls.Add(this.radioButton4);
            this.status.Location = new System.Drawing.Point(115, 290);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(200, 35);
            this.status.TabIndex = 14;
            this.status.TabStop = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(4, 10);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(66, 17);
            this.radioButton3.TabIndex = 1;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Menikah";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.Click += new System.EventHandler(this.radioButton4_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(105, 10);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(57, 17);
            this.radioButton4.TabIndex = 1;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Lajang";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.Click += new System.EventHandler(this.radioButton4_Click);
            // 
            // DetailPasangan
            // 
            this.DetailPasangan.Controls.Add(this.txtnamapasangan);
            this.DetailPasangan.Controls.Add(this.label28);
            this.DetailPasangan.Controls.Add(this.txtnoktppasangan);
            this.DetailPasangan.Controls.Add(this.label29);
            this.DetailPasangan.Controls.Add(this.txtalamatpasangan);
            this.DetailPasangan.Controls.Add(this.label30);
            this.DetailPasangan.Controls.Add(this.txtnotelppasangan);
            this.DetailPasangan.Controls.Add(this.label36);
            this.DetailPasangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DetailPasangan.Location = new System.Drawing.Point(15, 327);
            this.DetailPasangan.Name = "DetailPasangan";
            this.DetailPasangan.Size = new System.Drawing.Size(339, 121);
            this.DetailPasangan.TabIndex = 15;
            this.DetailPasangan.TabStop = false;
            this.DetailPasangan.VisibleChanged += new System.EventHandler(this.DetailPasangan_VisibleChanged);
            // 
            // areatagis
            // 
            this.areatagis.Location = new System.Drawing.Point(491, 241);
            this.areatagis.Name = "areatagis";
            this.areatagis.Size = new System.Drawing.Size(242, 20);
            this.areatagis.TabIndex = 27;
            // 
            // statusappl
            // 
            this.statusappl.Controls.Add(this.rdbsttsaplro);
            this.statusappl.Controls.Add(this.rdbsttsaplnew);
            this.statusappl.Location = new System.Drawing.Point(491, 263);
            this.statusappl.Name = "statusappl";
            this.statusappl.Size = new System.Drawing.Size(224, 37);
            this.statusappl.TabIndex = 28;
            this.statusappl.TabStop = false;
            // 
            // rdbsttsaplro
            // 
            this.rdbsttsaplro.AutoSize = true;
            this.rdbsttsaplro.Location = new System.Drawing.Point(68, 12);
            this.rdbsttsaplro.Name = "rdbsttsaplro";
            this.rdbsttsaplro.Size = new System.Drawing.Size(41, 17);
            this.rdbsttsaplro.TabIndex = 1;
            this.rdbsttsaplro.TabStop = true;
            this.rdbsttsaplro.Text = "RO";
            this.rdbsttsaplro.UseVisualStyleBackColor = true;
            // 
            // rdbsttsaplnew
            // 
            this.rdbsttsaplnew.AutoSize = true;
            this.rdbsttsaplnew.Location = new System.Drawing.Point(7, 12);
            this.rdbsttsaplnew.Name = "rdbsttsaplnew";
            this.rdbsttsaplnew.Size = new System.Drawing.Size(47, 17);
            this.rdbsttsaplnew.TabIndex = 0;
            this.rdbsttsaplnew.TabStop = true;
            this.rdbsttsaplnew.Text = "New";
            this.rdbsttsaplnew.UseVisualStyleBackColor = true;
            // 
            // Prov
            // 
            this.Prov.Location = new System.Drawing.Point(491, 42);
            this.Prov.Name = "Prov";
            this.Prov.Size = new System.Drawing.Size(54, 20);
            this.Prov.TabIndex = 227;
            // 
            // Kab
            // 
            this.Kab.Location = new System.Drawing.Point(591, 42);
            this.Kab.Name = "Kab";
            this.Kab.Size = new System.Drawing.Size(54, 20);
            this.Kab.TabIndex = 227;
            // 
            // Kec
            // 
            this.Kec.Location = new System.Drawing.Point(679, 42);
            this.Kec.Name = "Kec";
            this.Kec.Size = new System.Drawing.Size(54, 20);
            this.Kec.TabIndex = 227;
            // 
            // ds_data
            // 
            this.ds_data.DataSetName = "NewDataSet";
            this.ds_data.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2,
            this.dataTable3,
            this.dataTable4});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27});
            this.dataTable1.TableName = "NASABAH";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "NAMA_COSTUMER";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NO_KTP";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "NO_KK";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AGAMA";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TEMPAT_LAHIR";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TANGGAL_LAHIR";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "JK";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "ALAMAT_KTP";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "ALAMAT_DOMISILI";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TELP";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PEKERJAAN";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "NAMA_IBU_KANDUNG";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TANGGAL_LAHIR_IBU";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "NAMA_USAHA";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "ALAMAT_UsAHA";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "JENIS_USAHA";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "NAMA_BANK";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "NO_REKENING";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "NAMA_REKENING";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "NAMA_SALES";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "WILAYAH_AREA_TAGIH";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "STATUS_APPL";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "STATUS_MENIKAH";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "NAMA_PASANGAN";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "NO_KTP_PASANGAN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "ALAMAT_PASANGAN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TELP_PASANGAN";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36});
            this.dataTable2.TableName = "JAMINAN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NO_JAMINAN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "JENIS_JAMINAN";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "NO_ANGGOTA";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TANGGAL_MASUK";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "NAMA_BARANG";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TIPE_BARANG";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "KET1";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "KET2";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "NAMA_COLLECTOR";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn39,
            this.dataColumn40,
            this.dataColumn42,
            this.dataColumn41,
            this.dataColumn43});
            this.dataTable3.TableName = "SALES";
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "SALES_ID";
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "NM_SALES";
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "TELP_SALES";
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "ALAMAT_SALES";
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "IS_ACTIVE";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn44});
            this.dataTable4.TableName = "collector";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "NM_COLLECTOR";
            // 
            // namasales
            // 
            this.namasales.FormattingEnabled = true;
            this.namasales.Location = new System.Drawing.Point(492, 218);
            this.namasales.Name = "namasales";
            this.namasales.Size = new System.Drawing.Size(241, 21);
            this.namasales.TabIndex = 228;
            // 
            // F050101
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.namasales);
            this.Controls.Add(this.Kec);
            this.Controls.Add(this.Kab);
            this.Controls.Add(this.Prov);
            this.Controls.Add(this.statusappl);
            this.Controls.Add(this.areatagis);
            this.Controls.Add(this.DetailPasangan);
            this.Controls.Add(this.status);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.cbxAgama);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.txtNomorTelepon);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.txtTanggalLahirIbu);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtPekerjaan);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtNamaIbuKandung);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.dtmTanggalLahir);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtTempatLahir);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtNomorKK);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtNoAnggota);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtNamarek);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtNoRek);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtNamaBank);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAlamatDomisili);
            this.Controls.Add(this.txtAlamatKTp);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtTelp);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtJenisUsaha);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAlamatUsaha);
            this.Controls.Add(this.txtNamaUsaha);
            this.Controls.Add(this.txtNomorKTP);
            this.Controls.Add(this.txtNamaCustomer);
            this.Name = "F050101";
            this.Size = new System.Drawing.Size(746, 618);
            this.Load += new System.EventHandler(this.F050101_Load);
            this.status.ResumeLayout(false);
            this.status.PerformLayout();
            this.DetailPasangan.ResumeLayout(false);
            this.DetailPasangan.PerformLayout();
            this.statusappl.ResumeLayout(false);
            this.statusappl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtnotelppasangan;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtNomorTelepon;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtalamatpasangan;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtnoktppasangan;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtnamapasangan;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtTanggalLahirIbu;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtPekerjaan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtNamaIbuKandung;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DateTimePicker dtmTanggalLahir;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtTempatLahir;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtNomorKK;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtNoAnggota;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtNamarek;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNoRek;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNamaBank;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAlamatDomisili;
        private System.Windows.Forms.TextBox txtAlamatKTp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTelp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtJenisUsaha;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAlamatUsaha;
        private System.Windows.Forms.TextBox txtNamaUsaha;
        private System.Windows.Forms.TextBox txtNomorKTP;
        private System.Windows.Forms.TextBox txtNamaCustomer;
        private System.Windows.Forms.ComboBox cbxAgama;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox status;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.GroupBox DetailPasangan;
        private System.Windows.Forms.TextBox areatagis;
        private System.Windows.Forms.GroupBox statusappl;
        private System.Windows.Forms.RadioButton rdbsttsaplro;
        private System.Windows.Forms.RadioButton rdbsttsaplnew;
        private System.Windows.Forms.TextBox Prov;
        private System.Windows.Forms.TextBox Kab;
        private System.Windows.Forms.TextBox Kec;
        public System.Data.DataSet ds_data;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn44;
        private System.Windows.Forms.ComboBox namasales;
    }
}
